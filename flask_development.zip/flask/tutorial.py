
import os
from werkzeug.utils import secure_filename
from flask import Flask
from flask import redirect, url_for, send_from_directory
from flask import render_template, request, make_response, send_file
import zipfile


UPLOAD_FOLDER = '/Users/michelleyuu/Desktop/DATA298B/flask/upload_folder/'
ALLOWED_EXTENSIONS = {'pdf', 'png', 'jpg', 'jpeg'}

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1] in ALLOWED_EXTENSIONS

@app.route('/upload', methods=['GET', 'POST'])
def upload_file():
    if request.method == 'POST':
        file = request.files['file']
        #print(file)
        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
            return redirect(url_for('uploaded_file', filename=filename))
    return '''
    <!doctype html>
    <title>Upload new File</title>
    <h1>Upload new File</h1>
    <form action="" method=post enctype=multipart/form-data>
      <p><input type=file name=file>
         <input type=submit value=Upload>
    </form>
    '''

@app.route('/uploads/<filename>')
def uploaded_file(filename):
    filename = 'http://127.0.0.1:4999/uploads/' + filename
    return render_template('upload_success.html', filename = filename)

@app.route("/view")
def view():
    hists = os.listdir(UPLOAD_FOLDER)
    hists = [file for file in hists]
    return render_template('view.html', hists = hists)


@app.route("/home")
def home():
    return render_template("index.html")

if __name__ == "__main__":
    app.run(host='127.0.0.1', port=4999, debug=True)