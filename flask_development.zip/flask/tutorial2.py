
import os
from werkzeug.utils import secure_filename
from flask import Flask
from flask import redirect, url_for
from flask import render_template, request

UPLOAD_FOLDER = '/path/to/the/uploads'
ALLOWED_EXTENSIONS = {'pdf', 'png', 'jpg', 'jpeg'}

app = Flask(__name__)
#app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/success/<name>')
def success(name):
    return 'welcome %s' % name
 
@app.route('/upload', methods=['GET', 'POST'])
def cool_form():
    if request.method == 'POST':

        return redirect(url_for('upload'))
    return render_template('upload.html')

@app.route("/")
def home():
    return render_template("index.html")

if __name__ == "__main__":
    app.run(host='127.0.0.1', port=5000, debug=True)